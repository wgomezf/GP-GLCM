% Computes the best configuration of GLCM-based texture features 
% constructed using the GP algorithm.
function z = GP10feats(I)
% GLCM configurations
Offsets = [0 1;  %1. theta=0º,  d=1 
           0 2;  %2. theta=0º,  d=2  
           0 4;  %3. theta=0º,  d=4  
           0 8;  %4. theta=0º,  d=8  
          -2 2;  %5. theta=45º, d=2  
          -4 4;  %6. theta=45º, d=4  
          -1 0;  %7. theta=90º, d=1  
          -2 0;  %8. theta=90º, d=2 
          -4 0;  %9. theta=90º, d=4
          -8 0;  %10. theta=90º, d=8
          -1 -1; %11. theta=135º, d=1
          -8 -8];%12. theta=135º, d=8
% Compute GLCMs
Cij = graycomatrix(I,'Offset',Offsets,'NumLevels',16,'GrayLimits',[],'Symmetric',false);
% Calculate probabilities
Pij = Cij./sum(sum(Cij,2),1);
% Calculate statistics
mux_4_0    = MUX(Pij(:,:,9));
mux_4_45   = MUX(Pij(:,:,6));
sigy_2_0   = SIGY(Pij(:,:,2));
sigy_2_45  = SIGY(Pij(:,:,5));
hx_1_135   = HX(Pij(:,:,11));
hxy_8_90   = HXY(Pij(:,:,10));
hxy1_2_90  = HXY1(Pij(:,:,8));
hxy2_1_0   = HXY2(Pij(:,:,1));
hxy2_8_0   = HXY2(Pij(:,:,4));
hxy2_1_135 = HXY2(Pij(:,:,11));
% Calculate GP features
z1 = SUM2(LOG(SQRT(Pij(:,:,7))));
z2 = SUM2(MAX(DIV(Pij(:,:,9),Pij(:,:,3)),DIV(hxy1_2_90,hxy_8_90)));
z3 = SUM2(SUB(SUB(hxy2_8_0,Pij(:,:,12)),MAX(hxy2_1_135,hxy1_2_90)));
z4 = SUM2(ADD(MIN(mux_4_0,sigy_2_0),LOG(Pij(:,:,7))));
z5 = SUM2(SUB(ADD(hxy2_1_135,Pij(:,:,3)),ADD(Pij(:,:,4),hxy2_1_0)));
z6 = SUM2(SUB(DIV(mux_4_45,sigy_2_45),Pij(:,:,3)));
z7 = SUM2(LOG(MUL(Pij(:,:,6),Pij(:,:,11))));
z8 = SUM2(ADD(SUB(Pij(:,:,7),hx_1_135),INV(Pij(:,:,3))));
z9 = SUM2(SUB(SQRT(Pij(:,:,7)),hx_1_135));
z10 = SUM2(DIV(SUB(Pij(:,:,9),Pij(:,:,1)),DIV(Pij(:,:,9),Pij(:,:,3))));
z = [z1 z2 z3 z4 z5 z6 z7 z8 z9 z10]; % Feature vector