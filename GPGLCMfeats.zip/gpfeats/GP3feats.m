% Computes the three GLCM-based texture features that achieved 
% statistically similar classification performance to the best 
% configuration with 10 features (function GP10feats.m).
function z = GP3feats(I)
% GLCM configurations
Offsets = [0 2;  %1. theta=0º,  d=2
           0 4;  %2. theta=0º,  d=4
          -4 4;  %3. theta=45º, d=4
          -1 0;  %4. theta=90º, d=1
          -4 0;  %5. theta=90º, d=4
          -8 0]; %6. theta=90º, d=8
% Compute GLCMs
Cij = graycomatrix(I,'Offset',Offsets,'NumLevels',16,'GrayLimits',[],'Symmetric',false);
% Calculate probabilities
Pij = Cij./sum(sum(Cij,2),1);
% Calculate statistics
muy_4_0  = MUY(Pij(:,:,2));
hx_4_0   = HX(Pij(:,:,2));
hx_8_90  = HX(Pij(:,:,6));
hy_4_45  = HY(Pij(:,:,3));
hxy2_2_0 = HXY2(Pij(:,:,1));
% Calculate GP features
z1 = SUM2(SUB(DIV(Pij(:,:,4),muy_4_0),DIV(hxy2_2_0,hy_4_45)));
z2 = SUM2(DIV(hx_8_90,SUB(hx_4_0,Pij(:,:,4))));
z3 = SUM2(DIV(DIV(hy_4_45,hx_8_90),Pij(:,:,5)));
z  = [z1 z2 z3]; % Final texture feature vector