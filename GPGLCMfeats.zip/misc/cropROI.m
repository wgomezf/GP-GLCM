function [I2,B2] = cropROI(I,B)
[Y,X] = size(I);
[y,x] = find(B);
xmin  = max(min(x),1); xmax = min(max(x),X);
ymin  = max(min(y),1); ymax = min(max(y),Y);
B2    = B(ymin:ymax,xmin:xmax);
I2    = I(ymin:ymax,xmin:xmax);