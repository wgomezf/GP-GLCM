clearvars; close all; clc;
pathBUS = 'D:\Databases\BUS\Merged';
pathO = 'C:\Users\Will\Desktop\BUS';
T = readtable(fullfile(pathBUS,'bus_data.csv'));
idx = contains(T.Dataset,'OASBUD')|contains(T.Dataset,'BUSBRA');
fileNames = T.ID(~idx);
D = T.Dataset(~idx);
Y = categorical(T.Pathology(~idx))=='malignant';
N = numel(fileNames);
b = 0;
m = 0;
for i = 1:N
    % Read BUS image
    load(fullfile(pathBUS,'MAT',sprintf('%s.mat',fileNames{i})),'I','BW');
    I = cropROI(I,BW);
    if strcmpi(D{i},'Dataset B')
        D{i} = 'UDIAT';
    end
    if Y(i)
        m = m+1;
        fname = sprintf('%s_M_%03d.png',D{i},m);
    else
        b = b+1;
        fname = sprintf('%s_B_%03d.png',D{i},b);
    end
    imwrite(I,fullfile(pathO,fname),'png','BitDepth',8);
end