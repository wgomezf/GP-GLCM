% Square root
function y = SQRT(x)
y = sign(x).*sqrt(abs(x)); % Protected