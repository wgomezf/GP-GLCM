% Maximum
function z = MAX(x,y)
z = max(x,y);