% Multiplication
function z = MUL(x,y)
z = x.*y;