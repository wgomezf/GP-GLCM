% Double summation
function y = SUM2(x)
y = sum(sum(x,1),2);