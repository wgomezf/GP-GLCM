% Natural logarithm
function y = LOG(x)
x = abs(x);
y = log(x);
i = x < 1e-3;
y(i) = 0;

