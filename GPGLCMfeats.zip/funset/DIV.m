% Division
function z = DIV(x,y)
z = x./y; 
i = abs(y)<1e-3;
z(i) = 0; % Protected