% Inverse
function y = INV(x)
y = 1./x; 
i = abs(x)<1e-3;
y(i) = 0; % Protected