% Demo program to test the GLCM-based texture features constructed via GP
clearvars; close all; clc;
% App and data folders
addpath(fullfile(pwd,'funset/'),fullfile(pwd,'stats/'),...
        fullfile(pwd,'data/'),fullfile(pwd,'gpfeats/'),...
        fullfile(pwd,'misc/'))
% Option for 3 or 10 GP features
opt = 10;
% List of BUSI files (only tumor ROIs)
dirOutput = dir(fullfile(pwd,'BUSI','*.png'));
fileNames = fullfile(pwd,'BUSI',{dirOutput.name}');
% Arrays to save test data:
Xt = zeros(numel(fileNames),opt);   % texture features
Yt = false(numel(fileNames),1);     % class labels
for i = 1:numel(fileNames)
    % Read ROI image
    I = imread(fileNames{i});
    Xt(i,:) = eval(sprintf('GP%dfeats(I)',opt)); % Compute texture features
    Yt(i) = contains(fileNames{i},'malignant');  % Get class label
end
% Load training data from the BUS-BRA dataset 
load(sprintf('BUSBRA%dfeats.mat',opt),'X','Y');
% Train a logistic regression model
Mdl = fitmnr(X,Y);
% Predict on BUSI data
[Yp,Pr] = predict(Mdl,Xt);
% Classification performance
[perf,C] = binclassperf(Yt,Yp,Pr(:,2));
% Confusion matrix
figure;
confusionchart(C,{'Malignant' 'Benign'});
% Print results
idx = {'MCC','ACC','PRE','SEN','SPE','F1s','BAC','AUC'};
for i = 1:numel(idx)
    fprintf('%s: %0.3f\n',idx{i},perf(i));
end
