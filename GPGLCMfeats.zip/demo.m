% Demo program to test the GLCM-based texture features constructed via GP
clearvars; close all; clc;
% App and data folders
addpath(fullfile(pwd,'funset/'),fullfile(pwd,'stats/'),...
        fullfile(pwd,'data/'),fullfile(pwd,'gpfeats/'),...
        fullfile(pwd,'misc/'))
% Option for 3 or 10 GP features
feats = 3;
% List of BUSI files (only tumor ROIs)
dirOutput = dir(fullfile(pwd,'BUS','*.png'));
fileNames = fullfile(pwd,'BUS',{dirOutput.name}');
% Arrays to save test data:
Xt = zeros(numel(fileNames),feats);   % texture features
Yt = false(numel(fileNames),1);     % class labels
for i = 1:numel(fileNames)
    % Read ROI image
    I = imread(fileNames{i});
    Xt(i,:) = eval(sprintf('GP%dfeats(I)',feats)); % Compute texture features
    Yt(i) = contains(fileNames{i},'_M_');  % Get class label: Malignant=1 and Benign=0
end
% Load training data from the BUS-BRA dataset 
load(sprintf('BUSBRA%dfeats.mat',feats),'X','Y');
% Train a logistic regression model
Mdl = fitmnr(X,Y);
% Predict on BUSI data
[Yp,Pr] = predict(Mdl,Xt);
% Classification performance
[perf,C] = binclassperf(Yt,Yp,Pr(:,2));
% Confusion matrix
figure;
confusionchart(C,{'Malignant' 'Benign'});
% Print results
idx = {'MCC','ACC','PRE','SEN','SPE','F1s','BAC','AUC'};
for i = 1:numel(idx)
    fprintf('%s: %0.3f\n',idx{i},perf(i));
end
