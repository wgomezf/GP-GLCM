function z = HXY2(Pij)
Pxy = sum(Pij,2)*sum(Pij,1);
z   = -sum(sum(Pxy.*log2(Pxy+eps)));
