function z = HXY1(Pij)
Pxy = sum(Pij,2)*sum(Pij,1);
z = -sum(sum(Pij.*log2(Pxy+eps)));