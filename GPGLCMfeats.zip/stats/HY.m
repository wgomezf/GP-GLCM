function z = HY(Pij)
Py = sum(Pij,1);
z  = -sum(Py.*log2(Py+eps));