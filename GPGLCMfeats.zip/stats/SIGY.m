function z = SIGY(Pij)
[~,j] = meshgrid(1:size(Pij,1));
MUY   = sum(sum(j.*Pij));
z     = sum(sum(Pij.*((j-MUY).^2)))^0.5;