function z = HXY(Pij)
z  = -sum(sum(Pij.*log2(Pij+eps)));