function z = HX(Pij)
Px = sum(Pij,2);
z  = -sum(Px.*log2(Px+eps));