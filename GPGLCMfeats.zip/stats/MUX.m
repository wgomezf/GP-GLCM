function z = MUX(Pij)
[i,~] = meshgrid(1:size(Pij,1));
z = sum(sum(i.*Pij));