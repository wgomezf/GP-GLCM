function z = MUY(Pij)
[~,j] = meshgrid(1:size(Pij,1));
z = sum(sum(j.*Pij));